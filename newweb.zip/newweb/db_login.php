<?php 
session_start(); 
include ("DB.php");

$id = $_POST["id"];
$pw = $_POST["pw"];
$sql = "SELECT * FROM `test1` WHERE id='$id' AND pw='$pw'";
$r = mysqli_query($conn,$sql);
if($r){
    echo '<a href="logout.php">logout</a>';
    //header('location:index.php');
    
}
?>

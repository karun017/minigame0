<?php
    session_start();
    include('databass.php'); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container-sm" >
    <div class="header">
        <h2>Login</h2>
    </div>
    
    <form action="login_databass.php" method="post">
            <label for="name">รหัสประจำตัว</label>
            <div class="row g-3 align-items-center">
        
        <div class="col-auto">
            <input type="text" id="inputPassword6" name='code' class="form-control" aria-describedby="passwordHelpInline"placeholder="รหัส 11 ตัว">
        </div>
        </div>
            
            <label for="name">รหัสผ่าน</label>
            <div class="row g-3 align-items-center">
    
        <div class="col-auto">
            <input type="text" id="inputPassword6" name='code' class="form-control" aria-describedby="passwordHelpInline"placeholder="กรุณาใส่ รหัสผ่าน">
        </div>
        <div class="input-group">
            <button type="submit" class="btn btn-outline-success">login</button>
            <a class="btn btn-outline-primary" href="form_regiter.php" role="button">สมัครสมาชิก</a>
                </div>
                
                <div class="input-group">
                <br><a  class="btn btn-primary btn-sm" role="button" href="http://localhost/newweb/">กลับหน้าหลัก</a>
                </div>
    <form>
    </div>
</body>
</html>
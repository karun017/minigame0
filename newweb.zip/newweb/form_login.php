<?php 
    session_start();
    include("DB.php");
?>
<form action="db_login.php" method="post">
<h2>Login</h2>
<br>
<label for="id">ID</label><br>
<input type="text" name="id">
<br>
<label for="pw">Password</label><br>
<input type="password" name="pw">
<br>
<button type="submit">login</button>
<a href="index.php">Home</a>
</form>
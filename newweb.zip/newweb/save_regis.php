
<?php
#$conn = mysqli_connect("localhost","root","","WTF") or die("มิดจั๊ด");
require_once("databass.php");
$code = $_POST["code"];
$name = $_POST["name"];
$pw = $_POST["pw"];
$sql = "INSERT INTO `hellowhi` (`code`,`name`,`pw`) VALUES ('$code', '$name', '$pw');";
$r = mysqli_query($conn,$sql);

if(!$r){
    echo "สมัครเสร็จสิ้น"."<br>";
    
}

?>


<?php
$conn = mysqli_connect("localhost","root","","WTF",) or die("มิดจั๊ด");
?>

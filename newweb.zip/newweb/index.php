<?php session_start();
include("DB.php"); 
?>

<h2>Home</h2>
<?php if(isset($r)){
    echo '<a href="logout.php">logout</a>';
}
else{
    echo '<a href="form_login.php">login</a>'."<br>";
    
    echo '<a href="form_regis.php">register</a>';
} ?>
<?php 
session_start();
require_once("DB.php");

$id = $_POST["id"];
$pw = $_POST["pw"];
$email = $_POST["email"];
$sql = "INSERT INTO test1 (id,pw,email) 
VALUES('$id','$pw','$email') ";

$r = mysqli_query($conn,$sql);

if($r){
    header('location:index.php');
}
?>

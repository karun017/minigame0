<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
<body>
  
  <div class="container-sm">
    
  <div class="bg-success p-2 text-dark bg-opacity-25">
    <table class="table table-striped">  
      <thead>
      <table class="table table-striped">
      <thead>
      
        <tr>
        <div class="bg-success p-2 text-white">
          <th scope="col">รหัสนักศึกษา</th>
          <th scope="col">ชื่อ-สกุล</th>
          <th scope="col">Passwords</th>
          </div>
        </tr>
        
      </thead>
      <?php
      
    require_once("databass.php");
    $sql = "select * from hellowhi";
    $r = mysqli_query($conn,$sql);

    while($row = mysqli_fetch_row($r)){

    ?>
      <tbody>
        <tr>
            <td><?php echo $row[0]."<br>"; ?></td>
            <td><?php echo $row[1]."<br>"; ?></td>
            <td><?php echo $row[2]."<br>"; ?></td>

        </tr>


      </tbody>
    <?php
    }
    ?>
        
        
      
    </table>
    </div>
    </div>
<br><br><br><br><br><br><a  class="btn btn-primary" href="http://localhost/newweb/">กลับหน้าหลัก</a>
</body>
</html>
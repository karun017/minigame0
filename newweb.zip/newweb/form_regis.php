<?php 
session_start();
include("DB.php");
?>
<form action="db_regis.php" method="post">
<h2>Resigter</h2>
<br>
<label for="id">id</label><br>
<input type="text" name="id" >
<br>
<label for="pw">password</label><br>
<input type="password" name = "pw" >
<br>
<label for="email">E-mail</label><br>
<input type="email" name="email" >
<br>
<button type="submit">register</button>
<br>
<a href="index.php">Home</a>
</form>

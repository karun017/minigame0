<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-sm" >
    <br><h1>สมัครสมาชิก</h1>
    <form action="save_regis.php" method="post">
    <label for="code">รหัสนักศึกษา</label>
    <div class="row g-3 align-items-center">
  
  <div class="col-auto">
    <input type="text" id="inputPassword6" name='code' class="form-control" aria-describedby="passwordHelpInline"placeholder="รหัส 11 ตัว">
  </div>
  <div class="col-auto">  
    <label for="code">ชื่อผู้สมัคร</label>
    
    <div class="row g-3 align-items-center">
 
<div class="col-auto">
    <input type="text" id="inputPassword6" name='name' class="form-control" aria-describedby="passwordHelpInline"placeholder="ชื่อ-สกุล">
  </div>
  
  <div class="col-auto">
  </div>
    <label for="code">รหัสผ่าน</label>
    <div class="row g-3 align-items-center">
    <div class="col-auto">
    <input type="password" id="inputPassword6" name ='pw'class="form-control" aria-describedby="passwordHelpInline"placeholder="ใส่รหัสผ่าน">
  </div>
  <div class="col-auto">
    <span id="passwordHelpInline" class="form-text">
      Must be 6-20 characters long.
    </span>

</div>
    <br><br><div class="btn-group" role="group" aria-label="Basic example">
    <button type="submit" class="btn btn-success">Enter</button>
    <button type="reset" class="btn btn-warning">Reset</button>
</div>

<br><br><br><a  class="btn btn-primary" href="http://localhost/newweb/">กลับหน้าหลัก</a>


    </form>
    </div>
</body>
</html>
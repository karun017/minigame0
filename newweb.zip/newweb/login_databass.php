<?php
include("databass.php");
$code = $_POST['code'];
$pw = $_POST["pw"];

$sql = "SELECT * FROM hellowhi WHERE code = '$code'AND pw = '$pw' ";
$r = mysqli_query($conn,$sql);

if($r){
    
    header("location:index.php");  
      
}
echo "login อร่อย","<br>";
?>